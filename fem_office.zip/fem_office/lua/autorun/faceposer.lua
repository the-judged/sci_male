/* A work in progress faceflex editor for playermodels in general, will be added as it's own script for now */
-- THIS IS SCRAPPED

--[[ if SERVER then
	util.AddNetworkString("FaceFlexEditorConfirm")
	util.AddNetworkString("FaceFlexEditorStart")
	util.AddNetworkString("FaceFlexEditorEnd")

	net.Receive("FaceFlexEditorConfirm", function(len, ply)
		local data = net.ReadTable()
		local flexWeights = data.flexWeights
		local flexScale = data.flexScale

		for i, weight in pairs(flexWeights) do
			ply:SetFlexWeight(i - 1, weight)
		end

		ply:SetFlexScale(flexScale)
	end)

	net.Receive("FaceFlexEditorStart", function(len, ply)
		local plyName = ply:Nick()
		for _, v in ipairs(player.GetAll()) do
			if v:IsAdmin() then
				v:PrintMessage(HUD_PRINTCONSOLE, "[FaceFlexEditor] Player " .. plyName .. " is editing their flexes")
			end
		end
	end)

	net.Receive("FaceFlexEditorEnd", function(len, ply)
		local plyName = ply:Nick()
		for _, v in ipairs(player.GetAll()) do
			if v:IsAdmin() then
				v:PrintMessage(HUD_PRINTCONSOLE, "[FaceFlexEditor] Player " .. plyName .. " is finished editing their flexes")
			end
		end
	end)
end

if CLIENT then
	local flexPanel
	local flexControls = {}
	local storedFlexWeights = {}
	local modelPanel
	local weightScaleSlider

	local function OpenFaceFlexEditor()
		if IsValid(flexPanel) then flexPanel:Remove() end

		net.Start("FaceFlexEditorStart")
		net.SendToServer()

		flexControls = {}

		flexPanel = vgui.Create("DFrame")
		flexPanel:SetSize(600, 500)
		flexPanel:SetTitle("Face Flex Editor")
		flexPanel:SetVisible(true)
		flexPanel:Center()
		flexPanel:MakePopup()

		modelPanel = vgui.Create("DModelPanel", flexPanel)
		modelPanel:SetSize(0, 0)	-- 600, 600
		modelPanel:SetModel(LocalPlayer():GetModel())
		-- Scroll panel for our models flexes
		local scrollPanel = vgui.Create("DScrollPanel", flexPanel)
		scrollPanel:SetSize(250, 312)
		scrollPanel:SetPos(10, 30)

		local testLabel = vgui.Create("DLabel", flexPanel)
		testLabel:SetText("To set your face flexes, point a camera towards your model's face\nand experiment with the sliders.\n\nYour Playermodel would've been shown here...\nbut isn't for now since the flexes on the preview model didn't\nmatch with the players actual model. Sorry.")
		testLabel:SizeToContents()
		testLabel:SetPos(275, 30)

		local flexes = modelPanel.Entity:GetFlexNum()
		for i = 0, flexes - 1 do
			local flexName = modelPanel.Entity:GetFlexName(i)

			local slider = vgui.Create("DNumSlider", scrollPanel)
			slider:SetSize(250, 20)
			slider:SetPos(0, i * 26)
			slider:SetText(flexName)
			slider:SetMin(-1)
			slider:SetMax(2)
			slider:SetDecimals(2)

			if storedFlexWeights[i + 1] then
				slider:SetValue(storedFlexWeights[i + 1])
			else
				slider:SetValue(modelPanel.Entity:GetFlexWeight(i))
			end

			table.insert(flexControls, slider)
		end

		weightScaleSlider = vgui.Create("DNumSlider", flexPanel)
		weightScaleSlider:SetSize(250, 20)
		weightScaleSlider:SetPos(10, 400)
		weightScaleSlider:SetText("Weight Scale")
		weightScaleSlider:SetValue(1.0)
		weightScaleSlider:SetMin(0)
		weightScaleSlider:SetMax(2)
		weightScaleSlider:SetDecimals(2)
	

		local confirmButton = vgui.Create("DButton", flexPanel)
		confirmButton:SetSize(100, 30)
		confirmButton:SetPos(10, 350)
		confirmButton:SetText("Confirm")
		confirmButton.DoClick = function()
			for i, slider in ipairs(flexControls) do
				local value = slider:GetValue()

				storedFlexWeights[i] = value
			end

			net.Start("FaceFlexEditorConfirm")
			net.WriteTable({
				flexWeights = storedFlexWeights,
				flexScale = weightScaleSlider:GetValue()
			})
			net.SendToServer()
		end

		local resetButton = vgui.Create("DButton", flexPanel)
		resetButton:SetSize(100, 30)
		resetButton:SetPos(120, 350)
		resetButton:SetText("Reset Face")
		resetButton.DoClick = function()
			for i, slider in ipairs(flexControls) do
				slider:SetValue(0)
				storedFlexWeights[i] = 0
			end

			net.Start("FaceFlexEditorConfirm")
			net.WriteTable({
				flexWeights = storedFlexWeights,
				flexScale = weightScaleSlider:GetValue()
			})
			net.SendToServer()
		end

		local randomFlexesButton = vgui.Create("DButton", flexPanel)
		randomFlexesButton:SetSize(100, 30)
		randomFlexesButton:SetPos(230, 350)
		randomFlexesButton:SetText("Randomize Flexes")
		randomFlexesButton.DoClick = function()
			for i, slider in ipairs(flexControls) do
				local randomValue = math.random()
				slider:SetValue(randomValue)
				storedFlexWeights[i] = randomValue
			end

			net.Start("FaceFlexEditorConfirm")
			net.WriteTable({
				flexWeights = storedFlexWeights,
				flexScale = weightScaleSlider:GetValue()
			})
			net.SendToServer()
		end

		flexPanel.OnClose = function(self)
			net.Start("FaceFlexEditorEnd")
			net.SendToServer()
			self:Remove()
		end
	end

	concommand.Add("bmce_face_flex_editor", OpenFaceFlexEditor)
end ]]