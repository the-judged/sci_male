
-- BMCE SECURITY FORCE --
player_manager.AddValidModel( "BMCE Guard (Male)", "models/humans/pm/guard.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Guard (Male)", "models/humans/pm/guard.mdl" )
player_manager.AddValidHands( "BMCE Guard (Male)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Guard Hurt (Male)", "models/humans/pm/guard_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Guard Hurt (Male)", "models/humans/pm/guard_hurt.mdl" )
player_manager.AddValidHands( "BMCE Guard Hurt (Male)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Guard (Female)", "models/humans/pm/guard_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Guard (Female)", "models/humans/pm/guard_female.mdl" )
player_manager.AddValidHands( "BMCE Guard (Female)", "models/c_arms/c_secguard_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Guard Hurt (Female)", "models/humans/pm/guard_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Guard Hurt (Female)", "models/humans/pm/guard_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE Guard Hurt (Female)", "models/c_arms/c_secguard_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Guard (Otis)", "models/humans/pm/guard_otis.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Guard (Otis)", "models/humans/pm/guard_otis.mdl" )
player_manager.AddValidHands( "BMCE Guard (Otis)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Guard Hurt (Otis)", "models/humans/pm/guard_otis_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Guard Hurt (Otis)", "models/humans/pm/guard_otis_hurt.mdl" )
player_manager.AddValidHands( "BMCE Guard Hurt (Otis)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE FACULTY STAFF --
player_manager.AddValidModel( "BMCE Cafeteria Worker (Female)", "models/humans/pm/cafeteria_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Cafeteria Worker (Female)", "models/humans/pm/cafeteria_female.mdl" )
player_manager.AddValidHands( "BMCE Cafeteria Worker (Female)", "models/c_arms/c_femcafe_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Cafeteria Worker Hurt (Female)", "models/humans/pm/cafeteria_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Cafeteria Worker Hurt (Female)", "models/humans/pm/cafeteria_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE Cafeteria Worker Hurt (Female)", "models/c_arms/c_femcafe_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Cafeteria Worker (Male)", "models/humans/pm/cafeteria_male.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Cafeteria Worker (Male)", "models/humans/pm/cafeteria_male.mdl" )
player_manager.AddValidHands( "BMCE Cafeteria Worker (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Cafeteria Worker Hurt (Male)", "models/humans/pm/cafeteria_male_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Cafeteria Worker Hurt (Male)", "models/humans/pm/cafeteria_male_hurt.mdl" )
player_manager.AddValidHands( "BMCE Cafeteria Worker Hurt (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

-- Adam's Consistant cafe male

player_manager.AddValidModel( "BMCE Cafeteria Worker (Male 2)", "models/humans/pm/cafeteria_male_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Cafeteria Worker (Male 2)", "models/humans/pm/cafeteria_male_02.mdl" )
player_manager.AddValidHands( "BMCE Cafeteria Worker (Male 2)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Cafeteria Worker Hurt (Male 2)", "models/humans/pm/cafeteria_male_hurt_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Cafeteria Worker Hurt (Male 2)", "models/humans/pm/cafeteria_male_hurt_02.mdl" )
player_manager.AddValidHands( "BMCE Cafeteria Worker Hurt (Male 2)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Construction Worker (Male)", "models/humans/pm/construction_worker.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Construction Worker (Male)", "models/humans/pm/construction_worker.mdl" )
player_manager.AddValidHands( "BMCE Construction Worker (Male)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Construction Worker Hurt (Male)", "models/humans/pm/construction_worker_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Construction Worker Hurt (Male)", "models/humans/pm/construction_worker_hurt.mdl" )
player_manager.AddValidHands( "BMCE Construction Worker Hurt (Male)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Custodian Worker (Male)", "models/humans/pm/custodian.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Custodian Worker (Male)", "models/humans/pm/custodian.mdl" )
player_manager.AddValidHands( "BMCE Custodian Worker (Male)", "models/c_arms/c_custodian_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Custodian Worker Hurt (Male)", "models/humans/pm/custodian_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Custodian Worker Hurt (Male)", "models/humans/pm/custodian_hurt.mdl" )
player_manager.AddValidHands( "BMCE Custodian Worker Hurt (Male)", "models/c_arms/c_custodian_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Custodian Worker (Female)", "models/humans/pm/custodian_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Custodian Worker (Female)", "models/humans/pm/custodian_female.mdl" )
player_manager.AddValidHands( "BMCE Custodian Worker (Female)", "models/c_arms/c_custodian_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Custodian Worker Hurt (Female)", "models/humans/pm/custodian_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Custodian Worker Hurt (Female)", "models/humans/pm/custodian_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE Custodian Worker Hurt (Female)", "models/c_arms/c_custodian_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Maintenance Worker (Male)", "models/humans/pm/cwork.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Maintenance Worker (Male)", "models/humans/pm/cwork.mdl" )
player_manager.AddValidHands( "BMCE Maintenance Worker (Male)", "models/c_arms/c_cwork_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Maintenance Worker Hurt (Male)", "models/humans/pm/cwork_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Maintenance Worker Hurt (Male)", "models/humans/pm/cwork_hurt.mdl" )
player_manager.AddValidHands( "BMCE Maintenance Worker Hurt (Male)", "models/c_arms/c_cwork_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Maintenance Worker (Female)", "models/humans/pm/cwork_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Maintenance Worker (Female)", "models/humans/pm/cwork_female.mdl" )
player_manager.AddValidHands( "BMCE Maintenance Worker (Female)", "models/c_arms/c_cwork_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Maintenance Worker Hurt (Female)", "models/humans/pm/cwork_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Maintenance Worker Hurt (Female)", "models/humans/pm/cwork_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE Maintenance Worker Hurt (Female)", "models/c_arms/c_cwork_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Engineer Worker (Male)", "models/humans/pm/engineer.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Engineer Worker (Male)", "models/humans/pm/engineer.mdl" )
player_manager.AddValidHands( "BMCE Engineer Worker (Male)", "models/c_arms/c_engy_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Engineer Worker Hurt (Male)", "models/humans/pm/engineer_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Engineer Worker Hurt (Male)", "models/humans/pm/engineer_hurt.mdl" )
player_manager.AddValidHands( "BMCE Engineer Worker Hurt (Male)", "models/c_arms/c_engy_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Engineer Worker (Female)", "models/humans/pm/engineer_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Engineer Worker (Female)", "models/humans/pm/engineer_female.mdl" )
player_manager.AddValidHands( "BMCE Engineer Worker (Female)", "models/c_arms/c_engy_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Engineer Worker Hurt (Female)", "models/humans/pm/engineer_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Engineer Worker Hurt (Female)", "models/humans/pm/engineer_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE Engineer Worker Hurt (Female)", "models/c_arms/c_engy_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE EMS Firefighter (Male)", "models/humans/pm/fireman.mdl" )
list.Set( "PlayerOptionsModel", "BMCE EMS Firefighter (Male)", "models/humans/pm/fireman.mdl" )
player_manager.AddValidHands( "BMCE EMS Firefighter (Male)", "models/c_arms/c_firefighter_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE EMS Firefighter Hurt (Male)", "models/humans/pm/fireman_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE EMS Firefighter Hurt (Male)", "models/humans/pm/fireman_hurt.mdl" )
player_manager.AddValidHands( "BMCE EMS Firefighter Hurt (Male)", "models/c_arms/c_firefighter_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Police Officer", "models/humans/pm/cop.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Police Officer", "models/humans/pm/cop.mdl" )
player_manager.AddValidHands( "BMCE Police Officer", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE EMS Paramedic (Male)", "models/humans/pm/paramedic.mdl" )
list.Set( "PlayerOptionsModel", "BMCE EMS Paramedic (Male)", "models/humans/pm/paramedic.mdl" )
player_manager.AddValidHands( "BMCE EMS Paramedic (Male)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE EMS Paramedic Hurt (Male)", "models/humans/pm/paramedic_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE EMS Paramedic Hurt (Male)", "models/humans/pm/paramedic_hurt.mdl" )
player_manager.AddValidHands( "BMCE EMS Paramedic Hurt (Male)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor (Male)", "models/humans/pm/contractor.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor (Male)", "models/humans/pm/contractor.mdl" )
player_manager.AddValidHands( "BMCE Contractor (Male)", "models/c_arms/c_contractor_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor (Male 2)", "models/humans/pm/contractor_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor (Male 2)", "models/humans/pm/contractor_02.mdl" )
player_manager.AddValidHands( "BMCE Contractor (Male 2)", "models/c_arms/c_contractor_02_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor Hurt (Male)", "models/humans/pm/contractor_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor Hurt (Male)", "models/humans/pm/contractor_hurt.mdl" )
player_manager.AddValidHands( "BMCE Contractor Hurt (Male)", "models/c_arms/c_contractor_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor Hurt (Male 2)", "models/humans/pm/contractor_hurt_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor Hurt (Male 2)", "models/humans/pm/contractor_hurt_02.mdl" )
player_manager.AddValidHands( "BMCE Contractor Hurt (Male 2)", "models/c_arms/c_contractor_02_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor (Female)", "models/humans/pm/contractor_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor (Female)", "models/humans/pm/contractor_female.mdl" )
player_manager.AddValidHands( "BMCE Contractor (Female)", "models/c_arms/c_contractor_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor (Female 2)", "models/humans/pm/contractor_female_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor (Female 2)", "models/humans/pm/contractor_female_02.mdl" )
player_manager.AddValidHands( "BMCE Contractor (Female 2)", "models/c_arms/c_contractor_02_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor Hurt (Female)", "models/humans/pm/contractor_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor Hurt (Female)", "models/humans/pm/contractor_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE Contractor Hurt (Female)", "models/c_arms/c_contractor_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Contractor Hurt (Female 2)", "models/humans/pm/contractor_female_hurt_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Contractor Hurt (Female 2)", "models/humans/pm/contractor_female_hurt_02.mdl" )
player_manager.AddValidHands( "BMCE Contractor Hurt (Female 2)", "models/c_arms/c_contractor_02_female_arms.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE MAIN STAFF --
player_manager.AddValidModel( "BMCE Office Worker (Female)", "models/humans/pm/fem_office_worker.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Office Worker (Female)", "models/humans/pm/fem_office_worker.mdl" )
player_manager.AddValidHands( "BMCE Office Worker (Female)", "models/c_arms/c_office_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Office Worker Hurt (Female)", "models/humans/pm/fem_office_worker_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Office Worker Hurt (Female)", "models/humans/pm/fem_office_worker_hurt.mdl" )
player_manager.AddValidHands( "BMCE Office Worker Hurt (Female)", "models/c_arms/c_office_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Office Worker (Male)", "models/humans/pm/office_worker.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Office Worker (Male)", "models/humans/pm/office_worker.mdl" )
player_manager.AddValidHands( "BMCE Office Worker (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Office Worker Hurt (Male)", "models/humans/pm/office_worker_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Office Worker Hurt (Male)", "models/humans/pm/office_worker_hurt.mdl" )
player_manager.AddValidHands( "BMCE Office Worker Hurt (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Coat Closed (Male)", "models/humans/pm/scientist_cl.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Coat Closed (Male)", "models/humans/pm/scientist_cl.mdl" )
player_manager.AddValidHands( "BMCE Scientist Coat Closed (Male)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Hurt Coat Closed (Male)", "models/humans/pm/scientist_cl_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Hurt Coat Closed (Male)", "models/humans/pm/scientist_cl_hurt.mdl" )
player_manager.AddValidHands( "BMCE Scientist Hurt Coat Closed (Male)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist (Male)", "models/humans/pm/scientist.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist (Male)", "models/humans/pm/scientist.mdl" )
player_manager.AddValidHands( "BMCE Scientist (Male)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Hurt (Male)", "models/humans/pm/scientist_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Hurt (Male)", "models/humans/pm/scientist_hurt.mdl" )
player_manager.AddValidHands( "BMCE Scientist Hurt (Male)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist (Female)", "models/humans/pm/scientist_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist (Female)", "models/humans/pm/scientist_female.mdl" )
player_manager.AddValidHands( "BMCE Scientist (Female)", "models/c_arms/c_scientist_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Hurt (Female)", "models/humans/pm/scientist_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Hurt (Female)", "models/humans/pm/scientist_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE Scientist Hurt (Female)", "models/c_arms/c_scientist_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Casual (Male)", "models/humans/pm/scientist_casual.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Casual (Male)", "models/humans/pm/scientist_casual.mdl" )
player_manager.AddValidHands( "BMCE Scientist Casual (Male)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Casual Hurt (Male)", "models/humans/pm/scientist_casual_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Casual Hurt (Male)", "models/humans/pm/scientist_casual_hurt.mdl" )
player_manager.AddValidHands( "BMCE Scientist Casual Hurt (Male)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Cleansuit (Male)", "models/humans/pm/scientist_cleansuit.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Cleansuit (Male)", "models/humans/pm/scientist_cleansuit.mdl" )
player_manager.AddValidHands( "BMCE Scientist Cleansuit (Male)", "models/c_arms/c_hazmat_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Cleansuit Hurt (Male)", "models/humans/pm/scientist_cleansuit_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Cleansuit Hurt (Male)", "models/humans/pm/scientist_cleansuit_hurt.mdl" )
player_manager.AddValidHands( "BMCE Scientist Cleansuit Hurt (Male)", "models/c_arms/c_hazmat_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Surveyor (2015, Male)", "models/humans/pm/hev_male.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Surveyor (2015, Male)", "models/humans/pm/hev_male.mdl" )
player_manager.AddValidHands( "BMCE Scientist Surveyor (2015, Male)", "models/c_arms/c_hev_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist Surveyor (2012, Male)", "models/humans/pm/hev_male_2012.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist Surveyor (2012, Male)", "models/humans/pm/hev_male_2012.mdl" )
player_manager.AddValidHands( "BMCE Scientist Surveyor (2012, Male)", "models/c_arms/c_hev_arms.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE MILITARY --
player_manager.AddValidModel( "BMCE HECU OLD Marine (Male)", "models/humans/pm/marine_old.mdl" )
list.Set( "PlayerOptionsModel", "BMCE HECU OLD Marine (Male)", "models/humans/pm/marine_old.mdl" )
player_manager.AddValidHands( "BMCE HECU OLD Marine (Male)", "models/c_arms/c_hecu_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE HECU Marine (Male)", "models/humans/pm/marine.mdl" )
list.Set( "PlayerOptionsModel", "BMCE HECU Marine (Male)", "models/humans/pm/marine.mdl" )
player_manager.AddValidHands( "BMCE HECU Marine (Male)", "models/c_arms/c_hecu_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE HECU Romka Marine (Male)", "models/humans/pm/marine_romka.mdl" )
list.Set( "PlayerOptionsModel", "BMCE HECU Romka Marine (Male)", "models/humans/pm/marine_romka.mdl" )
player_manager.AddValidHands( "BMCE HECU Romka Marine (Male)", "models/c_arms/c_hecu_male_arms.mdl", 0, "00000000" )

-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE XENIANS --
player_manager.AddValidModel( "BMCE Alient Vortiguant", "models/player/bm_vortigaunt_pm.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Alien Vortiguant", "models/player/bm_vortigaunt_pm.mdl" )

player_manager.AddValidModel( "BMCE Alien Controller", "models/player/bm_controller_pm.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Alien Controller", "models/player/bm_controller_pm.mdl" )

player_manager.AddValidModel( "BMCE Alien Grunt", "models/player/bm_agrunt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Alien Grunt", "models/player/bm_agrunt.mdl" )

player_manager.AddValidModel( "BMCE Headcrab Zombie", "models/player/zombie_sci.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Headcrab Zombie", "models/player/zombie_sci.mdl" )
player_manager.AddValidHands( "BMCE Headcrab Zombie", "models/c_arms/bms_scientificzombie_hands.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE HECU Marine Zombie", "models/player/zombie_marine_pm.mdl" )
list.Set( "PlayerOptionsModel", "BMCE HECU Marine Zombie", "models/player/zombie_marine_pm.mdl" )
player_manager.AddValidHands( "BMCE HECU Marine Zombie", "models/c_arms/bms_scientificzombie_hands.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Guard Zombie", "models/player/zombie_guard_pm.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Guard Zombie", "models/player/bms_guardzombie_hands.mdl" )
player_manager.AddValidHands( "BMCE Guard Zombie", "models/c_arms/bms_guardzombie_hands.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------