-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE:R FACULTY STAFF --
player_manager.AddValidModel( "BMCE:R Administation Personnel (Male 1)", "models/humans_bmcer/pm/admin_male.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Administation Personnel (Male 1)", "models/humans_bmcer/pm/admin_male.mdl" )
player_manager.AddValidHands( "BMCE:R Administation Personnel (Male 1)", "models/c_arms/c_admin_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Administation Personnel (Male 2)", "models/humans_bmcer/pm/admin_male02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Administation Personnel (Male 2)", "models/humans_bmcer/pm/admin_male02.mdl" )
player_manager.AddValidHands( "BMCE:R Administation Personnel (Male 2)", "models/c_arms/c_admin_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Administation Personnel Hurt (Male 1)", "models/humans_bmcer/pm/admin_male_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Administation Personnel Hurt (Male 1)", "models/humans_bmcer/pm/admin_male_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Administation Personnel Hurt (Male 1)", "models/c_arms/c_admin_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service OSHA Employee (Male)", "models/humans_bmcer/pm/osha_inspector.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service OSHA Employee (Male)", "models/humans_bmcer/pm/osha_inspector.mdl" )
player_manager.AddValidHands( "BMCE:R Service OSHA Employee (Male)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service OSHA Employee Hurt (Male)", "models/humans_bmcer/pm/osha_inspector_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service OSHA Employee Hurt (Male)", "models/humans_bmcer/pm/osha_inspector_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Service OSHA Employee Hurt (Male)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Cafeteria Worker (Female)", "models/humans_bmcer/pm/cafeteria_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Cafeteria Worker (Female)", "models/humans_bmcer/pm/cafeteria_female.mdl" )
player_manager.AddValidHands( "BMCE:R Cafeteria Worker (Female)", "models/c_arms/c_femcafe_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Cafeteria Worker Hurt (Female)", "models/humans_bmcer/pm/cafeteria_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Cafeteria Worker Hurt (Female)", "models/humans_bmcer/pm/cafeteria_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Cafeteria Worker Hurt (Female)", "models/c_arms/c_femcafe_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Cafeteria Worker (Male)", "models/humans_bmcer/pm/cafeteria_male.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Cafeteria Worker (Male)", "models/humans_bmcer/pm/cafeteria_male.mdl" )
player_manager.AddValidHands( "BMCE:R Cafeteria Worker (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Cafeteria Worker Hurt (Male)", "models/humans_bmcer/pm/cafeteria_male_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Cafeteria Worker Hurt (Male)", "models/humans_bmcer/pm/cafeteria_male_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Cafeteria Worker Hurt (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Custodian Worker (Male)", "models/humans_bmcer/pm/custodian.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Custodian Worker (Male)", "models/humans_bmcer/pm/custodian.mdl" )
player_manager.AddValidHands( "BMCE:R Service Custodian Worker (Male)", "models/c_arms/c_custodian_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Custodian Worker Hurt (Male)", "models/humans_bmcer/pm/custodian_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Custodian Worker Hurt (Male)", "models/humans_bmcer/pm/custodian_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Service Custodian Worker Hurt (Male)", "models/c_arms/c_custodian_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Maintenance Worker (Male)", "models/humans_bmcer/pm/cwork.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Maintenance Worker (Male)", "models/humans_bmcer/pm/cwork.mdl" )
player_manager.AddValidHands( "BMCE:R Service Maintenance Worker (Male)", "models/c_arms/c_cwork_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Maintenance Worker Hurt (Male)", "models/humans_bmcer/pm/cwork_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Maintenance Worker Hurt (Male)", "models/humans_bmcer/pm/cwork_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Service Maintenance Worker Hurt (Male)", "models/c_arms/c_cwork_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Engineer Worker (Male)", "models/humans_bmcer/pm/engineer.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Engineer Worker (Male)", "models/humans_bmcer/pm/engineer.mdl" )
player_manager.AddValidHands( "BMCE:R Service Engineer Worker (Male)", "models/c_arms/c_engy_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Engineer Worker Hurt (Male)", "models/humans_bmcer/pm/engineer_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Engineer Worker Hurt (Male)", "models/humans_bmcer/pm/engineer_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Service Engineer Worker Hurt (Male)", "models/c_arms/c_engy_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Logistics Worker (Male)", "models/humans_bmcer/pm/logistic.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Logistics Worker (Male)", "models/humans_bmcer/pm/logistic.mdl" )
player_manager.AddValidHands( "BMCE:R Service Logistics Worker (Male)", "models/c_arms/c_logistics_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Service Technician Worker (Male)", "models/humans_bmcer/pm/technician.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Service Technician Worker (Male)", "models/humans_bmcer/pm/technician.mdl" )
player_manager.AddValidHands( "BMCE:R Service Technician Worker (Male)", "models/c_arms/c_tech_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R EMS Paramedic (Male)", "models/humans_bmcer/pm/paramedic.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R EMS Paramedic (Male)", "models/humans_bmcer/pm/paramedic.mdl" )
player_manager.AddValidHands( "BMCE:R EMS Paramedic (Male)", "models/c_arms/c_constr_arms.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE:R SECURITY FORCE --
player_manager.AddValidModel( "BMCE:R Guard (Male 1)", "models/humans_bmcer/pm/guard.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard (Male 1)", "models/humans_bmcer/pm/guard.mdl" )
player_manager.AddValidHands( "BMCE:R Guard (Male 1)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard Hurt (Male 1)", "models/humans_bmcer/pm/guard_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard Hurt (Male 1)", "models/humans_bmcer/pm/guard_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Guard Hurt (Male 1)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )


player_manager.AddValidModel( "BMCE:R Guard (Male 2)", "models/humans_bmcer/pm/guard_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard (Male 2)", "models/humans_bmcer/pm/guard_02.mdl" )
player_manager.AddValidHands( "BMCE:R Guard (Male 2)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard (Otis)", "models/humans_bmcer/pm/guard_otis.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard (Otis)", "models/humans_bmcer/pm/guard_otis.mdl" )
player_manager.AddValidHands( "BMCE:R Guard (Otis)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard Hurt (Otis)", "models/humans_bmcer/pm/guard_otis_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard Hurt (Otis)", "models/humans_bmcer/pm/guard_otis_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Guard Hurt (Otis)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard (Female)", "models/humans_bmcer/pm/guard_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard (Female)", "models/humans_bmcer/pm/guard_female.mdl" )
player_manager.AddValidHands( "BMCE:R Guard (Female)", "models/c_arms/c_secguard_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard Hurt (Female)", "models/humans_bmcer/pm/guard_female_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard Hurt (Female)", "models/humans_bmcer/pm/guard_female_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Guard Hurt (Female)", "models/c_arms/c_secguard_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Bodyguard (Male 1)", "models/humans_bmcer/pm/guard_bodyguard.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Bodyguard (Male 1)", "models/humans_bmcer/pm/guard_bodyguard.mdl" )
player_manager.AddValidHands( "BMCE:R Bodyguard (Male 1)", "models/c_arms/c_admin_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard F.R (Male 1)", "models/humans_bmcer/pm/guard_first_response.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard F.R (Male 1)", "models/humans_bmcer/pm/guard_first_response.mdl" )
player_manager.AddValidHands( "BMCE:R Guard F.R (Male 1)", "models/c_arms/c_secguard_hvy_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard F.R Hurt (Male 1)", "models/humans_bmcer/pm/guard_first_response_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard F.R Hurt (Male 1)", "models/humans_bmcer/pm/guard_first_response_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Guard F.R Hurt (Male 1)", "models/c_arms/c_secguard_hvy_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard Jacket (Male 1)", "models/humans_bmcer/pm/guard_jacket.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard Jacket (Male 1)", "models/humans_bmcer/pm/guard_jacket.mdl" )
player_manager.AddValidHands( "BMCE:R Guard Jacket (Male 1)", "models/c_arms/c_secguard_jacket_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard Jacket Hurt (Male 1)", "models/humans_bmcer/pm/guard_jacket_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard Jacket Hurt (Male 1)", "models/humans_bmcer/pm/guard_jacket_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Guard Jacket Hurt (Male 1)", "models/c_arms/c_secguard_jacket_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Guard HEV (Male 1)", "models/humans_bmcer/pm/hev_guard.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Guard HEV (Male 1)", "models/humans_bmcer/pm/hev_guard.mdl" )
player_manager.AddValidHands( "BMCE:R Guard HEV (Male 1)", "models/c_arms/c_hev_arms.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE:R MILITARY --
player_manager.AddValidModel( "BMCE:R HECU Marine Service Engineer (Male 1)", "models/humans_bmcer/pm/marine_engineer.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R HECU Marine Service Engineer (Male 1)", "models/humans_bmcer/pm/marine_engineer.mdl" )
player_manager.AddValidHands( "BMCE:R HECU Marine Service Engineer (Male 1)", "models/c_arms/c_hecu_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R HECU Marine Pilot (Male 1)", "models/humans_bmcer/pm/pilot.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R HECU Marine Pilot (Male 1)", "models/humans_bmcer/pm/pilot.mdl" )
player_manager.AddValidHands( "BMCE:R HECU Marine Pilot (Male 1)", "models/c_arms/c_hecu_male_arms.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE:R MAIN STAFF --
player_manager.AddValidModel( "BMCE:R Office Worker (Male)", "models/humans_bmcer/pm/office_worker.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Office Worker (Male)", "models/humans_bmcer/pm/office_worker.mdl" )
player_manager.AddValidHands( "BMCE:R Office Worker (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Office Worker Hurt (Male)", "models/humans_bmcer/pm/office_worker_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Office Worker Hurt (Male)", "models/humans_bmcer/pm/office_worker_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Office Worker Hurt (Male)", "models/c_arms/c_office_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist (Male 1)", "models/humans_bmcer/pm/scientist.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist (Male 1)", "models/humans_bmcer/pm/scientist.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist (Male 1)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Hurt (Male 1)", "models/humans_bmcer/pm/scientist_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Hurt (Male 1)", "models/humans_bmcer/pm/scientist_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Hurt (Male 1)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist (Male 2)", "models/humans_bmcer/pm/scientist_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist (Male 2)", "models/humans_bmcer/pm/scientist_02.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist (Male 2)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Hurt (Male 2)", "models/humans_bmcer/pm/scientist_hurt_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Hurt (Male 2)", "models/humans_bmcer/pm/scientist_hurt_02.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Hurt (Male 2)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Casual (Male 1)", "models/humans_bmcer/pm/scientist_casual.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Casual (Male 1)", "models/humans_bmcer/pm/scientist_casual.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Casual (Male 1)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Casual Hurt (Male 1)", "models/humans_bmcer/pm/scientist_casual_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Casual Hurt (Male 1)", "models/humans_bmcer/pm/scientist_casual_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Casual Hurt (Male 1)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Casual (Male 2)", "models/humans_bmcer/pm/scientist_casual_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Casual (Male 2)", "models/humans_bmcer/pm/scientist_casual_02.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Casual (Male 2)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Casual Hurt (Male 2)", "models/humans_bmcer/pm/scientist_casual_hurt_02.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Casual Hurt (Male 2)", "models/humans_bmcer/pm/scientist_casual_hurt_02.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Casual Hurt (Male 2)", "models/c_arms/c_secguard_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Coat Closed (Male 1)", "models/humans_bmcer/pm/scientist_cl.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Coat Closed (Male 1)", "models/humans_bmcer/pm/scientist_cl.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Coat Closed (Male 1)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Coat Closed Hurt (Male 1)", "models/humans_bmcer/pm/scientist_cl_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Coat Closed Hurt (Male 1)", "models/humans_bmcer/pm/scientist_cl_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Coat Closed Hurt (Male 1)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Cleansuit (Male 1)", "models/humans_bmcer/pm/scientist_cleansuit.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Cleansuit (Male 1)", "models/humans_bmcer/pm/scientist_cleansuit.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Cleansuit (Male 1)", "models/c_arms/c_hazmat_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Cleansuit Hurt (Male 1)", "models/humans_bmcer/pm/scientist_cleansuit_hurt.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Cleansuit Hurt (Male 1)", "models/humans_bmcer/pm/scientist_cleansuit_hurt.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Cleansuit Hurt (Male 1)", "models/c_arms/c_hazmat_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE Scientist (Female)", "models/humans_bmcer/pm/scientist_female.mdl" )
list.Set( "PlayerOptionsModel", "BMCE Scientist (Female)", "models/humans_bmcer/pm/scientist_female.mdl" )
player_manager.AddValidHands( "BMCE Scientist (Female)", "models/c_arms/c_scientist_female_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Vest Coat Closed (Male 1)", "models/humans_bmcer/pm/scientist_vest_cl.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Vest Coat Closed (Male 1)", "models/humans_bmcer/pm/scientist_vest_cl.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Vest Coat Closed (Male 1)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Vest (Male 1)", "models/humans_bmcer/pm/scientist_vest.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Vest (Male 1)", "models/humans_bmcer/pm/scientist_vest.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Vest (Male 1)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist Vest Casual (Male 1)", "models/humans_bmcer/pm/scientist_vest_casual.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist Vest Casual (Male 1)", "models/humans_bmcer/pm/scientist_vest_casual.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist Vest Casual (Male 1)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )
-----------------------------------------------------------------------------------------------------------------------------------
-- BMCE:R SPECIAL --
player_manager.AddValidModel( "BMCE:R Scientist (Dr. Eli Vance)", "models/humans_bmcer/pm/scientist_eli.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist (Dr. Eli Vance)", "models/humans_bmcer/pm/scientist_eli.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist (Dr. Eli Vance)", "models/c_arms/c_scientist_male_black_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist (Dr. Coomer)", "models/humans_bmcer/pm/scientist_coomer.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist (Dr. Coomer)", "models/humans_bmcer/pm/scientist_coomer.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist (Dr. Coomer)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )

player_manager.AddValidModel( "BMCE:R Scientist (Dr. Isaac Kliener)", "models/humans_bmcer/pm/scientist_kliener.mdl" )
list.Set( "PlayerOptionsModel", "BMCE:R Scientist (Dr. Isaac Kliener)", "models/humans_bmcer/pm/scientist_kliener.mdl" )
player_manager.AddValidHands( "BMCE:R Scientist (Dr. Isaac Kliener)", "models/c_arms/c_scientist_male_arms.mdl", 0, "00000000" )